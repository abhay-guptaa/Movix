# Movix
 Movie Web App created using React
